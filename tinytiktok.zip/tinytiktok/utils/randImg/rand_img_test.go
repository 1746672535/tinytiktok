package randImg

import (
	"fmt"
	"testing"
)

func TestRandImg(t *testing.T) {
	for i := 0; i < 10; i++ {
		fmt.Println(gen())
	}
}
