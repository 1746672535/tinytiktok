package yiyan

import (
	"fmt"
	"testing"
)

func TestYiYan(t *testing.T) {
	fmt.Println(genYiYan().Content)
}
